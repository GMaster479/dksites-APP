import { useEffect, useRef, useState } from 'react';
import { Button, Confirm } from '../components/Bits.jsx';
import { getEditOptions, applyEdit, uploadFile, importImage } from '../api/engine.js';

// STAGED EDITOR
// Tapping a palette/font/suggestion no longer regenerates the site. Every choice is
// STAGED into a pending list the person can review and un-stage. One "Apply changes"
// sends the whole batch as a single edit — one generation, one cost, one coherent pass.
// Rationale: exploring is free; committing is the transaction.

const stageKey = (id) => `dksites-pending-${id || 'none'}`;
const dismissKey = (id) => `dksites-dismissed-${id || 'none'}`;

// What the owner can hand us that public data never has. These asks are the most valuable
// thing on the screen — a real logo fixes the palette, a real menu replaces placeholders —
// so they sit above everything else. They're also dismissable: nobody should be nagged.
const ASK_KINDS = [
  { kind: 'logo',  test: /logo/i,                 cta: 'Upload logo',   accept: 'image/*',
    done: 'Logo added — you can match the colors to it afterward' },
  { kind: 'menu',  test: /menu|tap list/i,        cta: 'Upload menu',   accept: 'image/*,application/pdf', multiple: true,
    done: 'Menu uploaded — real items will replace the placeholders', repeatable: true,
    more: 'Add another page' },
  { kind: 'photo', test: /photo|picture|shot|gallery|hero/i, cta: 'Add photos', accept: 'image/*', multiple: true,
    done: 'Photos uploaded' },
];
const askKindFor = (text) => ASK_KINDS.find((k) => k.test.test(text || '')) || null;

// A palette is more than two colors when the brand calls for it — show every one the
// generator is actually using, not just dominant/accent.
function paletteColors(p) {
  if (!p) return [];
  const out = [];
  if (p.dominant) out.push({ role: 'dominant', hex: p.dominant });
  if (p.accent) out.push({ role: 'accent', hex: p.accent });
  for (const n of p.neutrals || []) out.push({ role: 'neutral', hex: n });
  for (const [k, v] of Object.entries(p)) {
    if (['dominant', 'accent', 'neutrals', 'label', 'source', 'rationale'].includes(k)) continue;
    if (typeof v === 'string' && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v)) out.push({ role: k, hex: v });
  }
  return out;
}

// Same idea for type: display + body, plus any extra roles the brand defined.
function fontList(f) {
  if (!f) return [];
  const roles = { display: 'headings', body: 'body text', accent: 'accents', mono: 'code' };
  return Object.entries(f)
    .filter(([k, v]) => typeof v === 'string' && k !== 'label' && v.length < 40)
    .map(([k, v]) => ({ role: roles[k] || k, name: v }));
}

export default function Editor({ go, project }) {
  const [opts, setOpts] = useState(null);
  const [pending, setPending] = useState([]);
  const [prompt, setPrompt] = useState('');
  const [applying, setApplying] = useState(false);
  const [frameKey, setFrameKey] = useState(0);
  const [dismissed, setDismissed] = useState([]);
  const [uploading, setUploading] = useState(null);
  const [uploadError, setUploadError] = useState(null);
  const [imgMode, setImgMode] = useState(false);
  const [target, setTarget] = useState(null);   // image clicked inside the preview
  const [linkUrl, setLinkUrl] = useState('');
  const [openPicker, setOpenPicker] = useState(null);
  const [applyStage, setApplyStage] = useState(null);
  const [applyError, setApplyError] = useState(null);
  const [lastSummary, setLastSummary] = useState(null);
  const [workingOn, setWorkingOn] = useState([]);        // what the "updating" screen lists
  const [confirmUndo, setConfirmUndo] = useState(null);   // a standing request to undo
  const [confirmRedesign, setConfirmRedesign] = useState(false);
  const [socialText, setSocialText] = useState(null);     // null = not editing
  const frameRef = useRef(null);

  // Load options + restore any staged-but-unapplied changes from a previous visit.
  useEffect(() => {
    getEditOptions(project.previewId).then(setOpts);
    try {
      const saved = JSON.parse(localStorage.getItem(stageKey(project.previewId)));
      if (Array.isArray(saved)) setPending(saved);
    } catch {}
    try {
      const d = JSON.parse(localStorage.getItem(dismissKey(project.previewId)));
      if (Array.isArray(d)) setDismissed(d);
    } catch {}
  }, []);

  function save(next) {
    setPending(next);
    try { localStorage.setItem(stageKey(project.previewId), JSON.stringify(next)); } catch {}
  }

  // Stage a change. `kind` is unique-per-slot for palette/fonts (re-tapping replaces the
  // previous pick instead of stacking two contradictory palettes); prompts accumulate.
  function stage(kind, label, instruction, unique = false) {
    const entry = { id: `${kind}-${Date.now()}`, kind, label, instruction };
    save(unique ? [...pending.filter((p) => p.kind !== kind), entry] : [...pending, entry]);
  }

  const unstage = (id) => save(pending.filter((p) => p.id !== id));
  const stagedOf = (kind) => pending.find((p) => p.kind === kind);

  // Bridge: the preview lives on another origin, so it posts messages instead of being
  // reached into. It only reports which image was clicked — every change still goes
  // through staging and a regeneration.
  useEffect(() => {
    const onMsg = (e) => {
      const d = e.data || {};
      if (d.type === 'dksites:ready' && imgMode) {
        frameRef.current?.contentWindow?.postMessage({ type: 'dksites:enable' }, '*');
      }
      if (d.type === 'dksites:image-click') { setTarget(d); setLinkUrl(''); setUploadError(null); }
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, [imgMode]);

  useEffect(() => {
    frameRef.current?.contentWindow?.postMessage(
      { type: imgMode ? 'dksites:enable' : 'dksites:disable' }, '*'
    );
    if (!imgMode) setTarget(null);
  }, [imgMode, frameKey]);

  // Stage a swap for the image the person clicked in the preview.
  function stageReplacement(rec, note) {
    const t = target;
    setPending((prev) => {
      const entry = {
        id: `swap-${Date.now()}`,
        kind: `swap-${t?.src || Date.now()}`,
        label: `Replace image: ${(t?.src || '').split('/').pop()} ${note}`,
        instruction: `Replace the image currently at "${t?.src}" with "${rec.assetPath}" everywhere it appears. Keep the same placement, size and treatment.`,
        upload: { kind: 'photo', records: [rec] },
      };
      const next = [...prev.filter((p) => p.kind !== entry.kind), entry];
      try { localStorage.setItem(stageKey(project.previewId), JSON.stringify(next)); } catch {}
      return next;
    });
    setTarget(null);
  }

  async function replaceByUpload(fileList) {
    const f = (fileList || [])[0];
    if (!f) return;
    setUploading('swap'); setUploadError(null);
    try {
      const rec = await uploadFile(project.previewId, 'photo', f);
      stageReplacement(rec, '(uploaded)');
    } catch (e) { setUploadError(e.message || 'Upload failed.'); }
    setUploading(null);
  }

  async function replaceByLink() {
    if (!linkUrl.trim()) return;
    setUploading('swap'); setUploadError(null);
    try {
      const rec = await importImage(project.previewId, linkUrl.trim());
      stageReplacement(rec, '(from link)');
    } catch (e) { setUploadError(e.message || 'Could not fetch that image.'); }
    setUploading(null);
  }

  function dismiss(text) {
    const next = [...dismissed, text];
    setDismissed(next);
    try { localStorage.setItem(dismissKey(project.previewId), JSON.stringify(next)); } catch {}
  }

  // Uploads STAGE like every other change — the file goes to the server immediately (so it
  // survives a reload) but nothing regenerates until Apply, per the staged-editor rule.
  async function handleUpload(spec, fileList) {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    setUploading(spec.kind);
    setUploadError(null);
    try {
      const recs = [];
      for (const f of files) recs.push(await uploadFile(project.previewId, spec.kind, f));
      // Photos and MENU PAGES accumulate — a two-page menu arrives as two files, and
      // uploading the second must not discard the first. Only the logo replaces.
      const accumulates = spec.kind === 'photo' || spec.kind === 'menu';
      const entry = {
        id: `${spec.kind}-${Date.now()}`,
        kind: accumulates ? `${spec.kind}-${Date.now()}` : spec.kind,
        label:
          spec.kind === 'photo' ? `${recs.length} photo${recs.length > 1 ? 's' : ''} uploaded`
          : spec.kind === 'menu' ? `Menu page${recs.length > 1 ? 's' : ''} uploaded (${recs.length})`
          : spec.done,
        instruction: null,
        upload: { kind: spec.kind, records: recs },
      };
      save(accumulates ? [...pending, entry] : [...pending.filter((p) => p.kind !== spec.kind), entry]);
    } catch (e) {
      setUploadError(e.message || 'Upload failed.');
    }
    setUploading(null);
  }

  async function applyAll() {
    if (!pending.length) return;
    setApplyError(null);
    setWorkingOn(pending.map((p) => p.label));
    setApplying(true);
    setApplyStage('Sending your changes…');

    // Each typed change goes on its own, so it can be undone on its own later. Color and
    // font picks travel as structured settings, not as words.
    const instructions = pending
      .filter((p) => p.instruction && p.kind !== 'palette' && p.kind !== 'fonts')
      .map((p) => p.instruction);
    const setSocials = stagedOf('socials')?.payload || null;
    const uploads = pending.filter((p) => p.upload);
    const logoFile = uploads.find((u) => u.upload.kind === 'logo')?.upload.records[0] || null;
    const menuRecords = uploads.filter((u) => u.upload.kind === 'menu').flatMap((u) => u.upload.records);
    const menuFile = menuRecords[0] || null;      // back-compat for a single page
    const photoFiles = uploads.filter((u) => u.upload.kind === 'photo').flatMap((u) => u.upload.records);
    // Colour and type go as STRUCTURED picks, not just prose. That's what updates the
    // stored decisions — otherwise the "in use" panel keeps showing the old values.
    const setPalette = stagedOf('palette')?.payload || null;
    const setFonts = stagedOf('fonts')?.payload || null;

    try {
      const r = await applyEdit(
        project.previewId,
        { instructions, slug: project.slug, logoFile, menuFile, menuFiles: menuRecords, photoFiles, setPalette, setFonts, setSocials },
        (stage) => setApplyStage(stage)
      );
      setLastSummary(r?.summary || 'Your changes are on your site.');
      save([]);
      try { setOpts(await getEditOptions(project.previewId)); } catch {}
      setFrameKey((k) => k + 1);
      setApplying(false);
    } catch (e) {
      setApplyError(e.message || 'Something went wrong while making your changes.');
      setApplying(false);
    }
  }

  // One-off edits that don't go through the staged list: undo an earlier change, or start
  // over with a fresh design. Both confirm first.
  async function runNow(change, label) {
    setApplyError(null); setWorkingOn([]); setApplying(true); setApplyStage(label);
    try {
      const r = await applyEdit(project.previewId, { slug: project.slug, ...change }, (stage) => setApplyStage(stage));
      setLastSummary(r?.summary || 'Done.');
      try { setOpts(await getEditOptions(project.previewId)); } catch {}
      setFrameKey((k) => k + 1);
    } catch (e) {
      setApplyError(e.message || 'That didn’t go through. Your site wasn’t changed.');
    }
    setApplying(false);
  }

  // ---- Applying: show the person their own decisions while they wait ----
  if (applying) {
    return (
      <div className="center container">
        <div className="spinner" />
        <h1>Updating your site</h1>
        <p className="sub">{applyStage || 'Making your changes.'} Usually 1 to 3 minutes. Only what you asked for is changing.</p>
        <div className="stack" style={{ textAlign: 'left' }}>
          {workingOn.map((label, i) => (
            <div key={i} className="card" style={{ padding: '10px 14px' }}>{label}</div>
          ))}
        </div>
      </div>
    );
  }

  const selPalette = stagedOf('palette')?.payload;

  // Placeholder written against THIS build by the options pass, so it never reads like a
  // canned example from someone else's site. Rotates so it doesn't feel like one command.
  const examples = opts?.examplePrompts?.length ? opts.examplePrompts : null;
  const placeholderText = examples
    ? `e.g. ${examples[Math.floor(Date.now() / 60000) % examples.length]}`
    : 'e.g. make the hero photo bigger, and use warmer colors in the footer';

  // Asks come from triage (what the build is missing) plus the editor's own suggestions.
  // The panel carries only the things ONLY the owner can supply: the triage asks plus any
  // high-priority prompt. Everything else is a nice-to-have and lives in the sidebar.
  const rawAsks = [
    ...(project.suggestedAsks || []),
    ...(opts?.suggestedPrompts || []).filter((p) => p.priority === 'high').map((p) => p.label),
  ].map((a) => String(a || '').trim()).filter((a) => a.length > 3);
  // An ask is retired when the owner has already provided that thing — the server's
  // `provided` flags are the truth, not the asks captured back at generation time.
  const provided = opts?.provided || {};
  const satisfied = (ask) => {
    const spec = askKindFor(ask);
    if (!spec) return false;
    if (spec.kind === 'logo') return !!provided.logo;
    if (spec.kind === 'menu') return !!provided.menu && !pending.some((p) => p.upload?.kind === 'menu');
    if (spec.kind === 'photo') return (provided.uploadedPhotos || 0) > 0;
    return false;
  };
  const asks = [...new Set(rawAsks)].filter((a) => a && !dismissed.includes(a) && !satisfied(a));

  return (
    <div className="container">
      {/* The mental model, stated plainly. People arrive expecting drag-and-drop; this is
          the opposite — the site is already built, and changes are described, batched, and
          rebuilt. Saying so up front prevents the "why isn't anything happening" moment. */}
      <section className="howto">
        <div className="howto__step">
          <span className="howto__n howto__n--done">✓</span>
          <div><strong>{project.live ? 'Your site is live.' : 'Your site is built.'}</strong> <span className="muted">{project.live ? 'Changes you make here go straight to your real website.' : 'You can open it on any device with the preview link below.'}</span></div>
        </div>
        <div className="howto__step">
          <span className="howto__n">2</span>
          <div><strong>Tell me what to change.</strong> <span className="muted">Describe it in your own words, pick new colors or fonts, or tap a photo to swap it. Add as many as you like; they wait in a list until you’re ready.</span></div>
        </div>
        <div className="howto__step">
          <span className="howto__n">3</span>
          <div><strong>Press “Update my site”.</strong> <span className="muted">Only the things you asked for change. Everything else, including your earlier changes, stays exactly as it is. Takes a minute or two.</span></div>
        </div>
      </section>

      {lastSummary && (
        <div className="summary" role="status">
          <div><strong style={{ fontFamily: 'var(--display)' }}>Your site is updated.</strong> <span className="muted" style={{ color: 'var(--paper-dim)' }}>{lastSummary}</span></div>
          <button className="ask__x" style={{ position: 'static' }} onClick={() => setLastSummary(null)} aria-label="Dismiss">×</button>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
        <h2>{project.business?.name || 'Your site'}</h2>
        <button type="button" role="switch" aria-checked={imgMode} className={`switch ${imgMode ? 'switch--on' : ''}`} onClick={() => setImgMode(!imgMode)}>
          <span className="switch__track" /><span>Tap a photo on the site to replace it</span>
        </button>
      </div>

      <div className="editor">
        {/* LEFT: the real generated site (stays in view on desktop while you scroll the controls) */}
        <div className="preview-col">
        <div className="preview-frame">
          {project.previewUrl ? (
            <iframe ref={frameRef} key={frameKey} src={project.previewUrl} title="Your generated site"
              style={{ width: '100%', height: '100%', minHeight: 560, border: 0, display: 'block' }} />
          ) : (
            <div style={{ padding: 24, color: '#111' }}>No preview yet.</div>
          )}
        </div>
        {project.previewUrl && (
          <div className="preview-actions">
            <a className="chip" href={project.live && project.domain ? `https://${project.domain}` : project.previewUrl} target="_blank" rel="noreferrer">
              {project.live ? 'Open my website' : 'Open the preview in a new tab'}
            </a>
            {imgMode && <span className="muted">Tap any photo on the site to swap it.</span>}
          </div>
        )}
        </div>

        {/* RIGHT: controls — every tap STAGES, nothing rebuilds until Apply */}
        <div>
      {asks.length > 0 && (
                <section className="asks">
                  <p className="eyebrow" style={{ marginBottom: 10 }}>Make this site yours — {asks.length} thing{asks.length > 1 ? 's' : ''} I couldn't get on my own</p>
                  <div className="asks__grid">
                    {asks.map((ask) => {
                      const spec = askKindFor(ask);
                      const staged = spec && pending.some((p) => p.kind === spec.kind || p.kind.startsWith(`${spec.kind}-`));
                      return (
                        <div key={ask} className="ask">
                          <button className="ask__x" onClick={() => dismiss(ask)} aria-label="Dismiss">×</button>
                          <p className="ask__text">{ask}</p>
                          {spec ? (
                            staged ? (
                              <span className="ask__done">✓ Added to your changes</span>
                            ) : (
                              <label className="btn btn--gold ask__btn">
                                {uploading === spec.kind ? 'Uploading…' : spec.cta}
                                <input type="file" accept={spec.accept} multiple={!!spec.multiple} hidden
                                  disabled={uploading === spec.kind}
                                  onChange={(e) => handleUpload(spec, e.target.files)} />
                              </label>
                            )
                          ) : (
                            <button className="btn btn--ghost ask__btn"
                              onClick={() => { stage(`ask-${ask.slice(0, 20)}`, ask, ask, true); dismiss(ask); }}>
                              Add to my changes
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  {uploadError && <p className="ask__err">{uploadError}</p>}
                </section>
              )}

          {applyError && (
            <div className="alert">
              <strong>That didn't go through.</strong>
              <p className="muted" style={{ margin: '4px 0 10px' }}>{applyError}</p>
              <p className="muted" style={{ margin: '0 0 10px' }}>Your changes are still staged below — nothing was lost.</p>
              <Button variant="ghost" onClick={applyAll}>Try again</Button>
            </div>
          )}

          <p className="muted" style={{ marginTop: 0 }}>
            Add as many changes as you like. Nothing changes on your site until you press <strong>Update my site</strong>.
          </p>

          {!opts ? <p className="muted">Loading options…</p> : (
            <>
              <div className="zone">
                <h3>Colors in use</h3>
                <div className="current">
                  <div className="current__swatches">
                    {paletteColors(selPalette || opts.palette.current).map((c, i) => (
                      <span key={i} className="swatch swatch--lg" style={{ background: c.hex }} title={`${c.role}: ${c.hex}`} />
                    ))}
                  </div>
                  <div className="current__meta">
                    {paletteColors(selPalette || opts.palette.current).map((c) => c.hex).join('  ·  ')}
                  </div>
                  <button className="chip" onClick={() => setOpenPicker(openPicker === 'palette' ? null : 'palette')}>
                    {openPicker === 'palette' ? 'Close' : 'Change colors'}
                  </button>
                </div>

                {openPicker === 'palette' && (
                  <div className="picker">
                    {[opts.palette.current, ...opts.palette.alternates].map((p, i) => {
                      const on = selPalette ? selPalette.dominant === p.dominant : i === 0;
                      return (
                        <button key={i} className={`picker__opt ${on ? 'picker__opt--on' : ''}`}
                          onClick={() => {
                            const e = { id: `palette-${Date.now()}`, kind: 'palette', payload: p,
                              label: `Colors: ${p.label || 'current'}`,
                              instruction: `Change the color palette to dominant ${p.dominant}, accent ${p.accent}` +
                                (p.neutrals?.length ? `, neutrals ${p.neutrals.join(', ')}` : '') +
                                `${p.label ? ` (${p.label})` : ''}.` };
                            save([...pending.filter((x) => x.kind !== 'palette'), e]);
                          }}>
                          <span className="picker__swatches">
                            {paletteColors(p).map((c, j) => (
                              <span key={j} className="swatch" style={{ background: c.hex }} />
                            ))}
                          </span>
                          <span>{p.label || 'Current'}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="zone">
                <h3>Type in use</h3>
                <div className="current">
                  <div className="current__meta current__meta--type">
                    {fontList(stagedOf('fonts')?.payload || opts.fonts.current).map((f, i) => (
                      <div key={i}><strong>{f.name}</strong> <span className="muted">— {f.role}</span></div>
                    ))}
                  </div>
                  <button className="chip" onClick={() => setOpenPicker(openPicker === 'fonts' ? null : 'fonts')}>
                    {openPicker === 'fonts' ? 'Close' : 'Change fonts'}
                  </button>
                </div>

                {openPicker === 'fonts' && (
                  <div className="picker">
                    {[opts.fonts.current, ...opts.fonts.alternates].map((f, i) => {
                      const cur = stagedOf('fonts')?.payload;
                      const on = cur ? cur.display === f.display : i === 0;
                      return (
                        <button key={i} className={`picker__opt ${on ? 'picker__opt--on' : ''}`}
                          onClick={() => {
                            const e = { id: `fonts-${Date.now()}`, kind: 'fonts', payload: f,
                              label: `Type: ${fontList(f).map((x) => x.name).join(' + ')}`,
                              instruction: `Change the typography to ${fontList(f).map((x) => `${x.name} for ${x.role}`).join(', ')}.` };
                            save([...pending.filter((x) => x.kind !== 'fonts'), e]);
                          }}>
                          <span>{fontList(f).map((x) => x.name).join(' + ')}</span>
                          {f.label && <span className="muted"> — {f.label}</span>}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <p className="muted" style={{ margin: '-4px 0 18px' }}>
                None of these feel right? Describe what you want in the box below — colors,
                a font name, a mood. Browse{' '}
                <a href="https://fonts.google.com" target="_blank" rel="noreferrer">Google Fonts</a>{' '}
                or grab a hex code from a{' '}
                <a href="https://coolors.co/generate" target="_blank" rel="noreferrer">color picker</a>{' '}
                and tell me what you found.
              </p>

              {(() => {
                // Low-priority extras only: no blanks, nothing already shown in the panel
                // above, nothing dismissed, and nothing already staged.
                const extras = (opts.suggestedPrompts || []).filter(
                  (sp) =>
                    sp.priority !== 'high' &&
                    String(sp.label || '').trim().length > 3 &&
                    !askKindFor(sp.label) &&
                    !dismissed.includes(sp.label) &&
                    !pending.some((p) => p.label === sp.label)
                );
                if (!extras.length) return null;
                return (
                  <div className="zone">
                    <h3>Also worth considering</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      {extras.map((sp, i) => (
                        <button key={i} className="chip" style={{ textAlign: 'left' }}
                          onClick={() => stage(`sugg-${sp.label.slice(0, 24)}`, sp.label, sp.prompt || sp.label, true)}>
                          + {sp.label}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })()}

              <div className="zone">
                <h3>Where else people find you</h3>
                {socialText === null ? (
                  <>
                    {(stagedOf('socials')?.payload || opts.socials || []).length ? (
                      <ul className="requests">
                        {(stagedOf('socials')?.payload || opts.socials).map((u) => <li key={u}><span style={{ wordBreak: 'break-all' }}>{u}</span></li>)}
                      </ul>
                    ) : <p className="muted" style={{ margin: 0 }}>No Facebook, Instagram or other pages on your site yet.</p>}
                    <button className="chip" style={{ marginTop: 10 }}
                      onClick={() => setSocialText((stagedOf('socials')?.payload || opts.socials || []).join('\n'))}>
                      {(opts.socials || []).length ? 'Change these links' : 'Add Facebook, Instagram and others'}
                    </button>
                  </>
                ) : (
                  <div className="stack">
                    <label htmlFor="soc">One link per line <span className="hint">e.g. https://www.facebook.com/yourbusiness</span></label>
                    <textarea id="soc" className="input" style={{ minHeight: 100 }} autoCapitalize="off" spellCheck={false}
                      value={socialText} onChange={(e) => setSocialText(e.target.value)} />
                    <div className="row">
                      <Button variant="ghost" onClick={() => {
                        const list = socialText.split(/[\s,]+/).map((x) => x.trim()).filter(Boolean)
                          .map((x) => (/^https?:\/\//i.test(x) ? x : `https://${x.replace(/^\/+/, '')}`));
                        save([...pending.filter((x) => x.kind !== 'socials'), {
                          id: `socials-${Date.now()}`, kind: 'socials', payload: list, instruction: null,
                          label: list.length ? `Social links (${list.length})` : 'Remove social links',
                        }]);
                        setSocialText(null);
                      }}>Add to my changes</Button>
                      <button className="link" onClick={() => setSocialText(null)}>Cancel</button>
                    </div>
                  </div>
                )}
              </div>

              {opts.requests?.length > 0 && (
                <div className="zone">
                  <h3>Changes you’ve asked for</h3>
                  <p className="muted" style={{ margin: '0 0 10px' }}>These stay on your site through every future change. Undo one if you change your mind.</p>
                  <ul className="requests">
                    {opts.requests.map((r) => (
                      <li key={r.id}>
                        <span>{r.text}</span>
                        <button className="link" onClick={() => setConfirmUndo(r)}>Undo</button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="zone">
                <h3>Ask for any change</h3>
                <label htmlFor="ask" className="hint" style={{ marginBottom: 8 }}>Be as specific as you can, like “make the phone number bigger in the top bar”. Small requests make small changes.</label>
                <textarea id="ask" className="input" placeholder={placeholderText}
                  value={prompt} onChange={(e) => setPrompt(e.target.value)} />
                <Button variant="ghost" style={{ marginTop: 10 }} disabled={prompt.trim().length < 4}
                  onClick={() => { stage(`prompt-${Date.now()}`, prompt.trim(), prompt.trim()); setPrompt(''); }}>
                  Add to my changes
                </Button>
              </div>
            </>
          )}

          {/* PENDING LIST — the staged batch, each removable */}
          <div className="zone">
            <h3>Waiting to be added {pending.length ? `(${pending.length})` : ''}</h3>
            {!pending.length ? (
              <p className="muted">Nothing yet. Your site stays exactly as it is.</p>
            ) : (
              <div className="pending">
                {pending.map((p) => (
                  <span key={p.id} className="chip" style={{ display: 'inline-flex', gap: 8, alignItems: 'center' }}>
                    {p.label}
                    <button onClick={() => unstage(p.id)} aria-label={`Remove ${p.label}`}
                      style={{ background: 'none', border: 'none', color: 'var(--stone)', cursor: 'pointer', fontSize: '1.2rem', lineHeight: 1, padding: '2px 4px' }}>×</button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="zone">
            <h3>Not feeling it?</h3>
            <p className="muted" style={{ margin: '0 0 10px' }}>Get a completely new design. Your business info, photos and the changes you’ve asked for are kept.</p>
            <Button variant="ghost" onClick={() => setConfirmRedesign(true)}>Start over with a fresh design</Button>
          </div>
        </div>
      </div>

      {confirmUndo && (
        <Confirm title="Undo this change?" yes="Undo it" onNo={() => setConfirmUndo(null)}
          onYes={() => { const r = confirmUndo; setConfirmUndo(null); runNow({ removeRequestId: r.id }, 'Undoing that change…'); }}>
          <p style={{ margin: 0 }}>“{confirmUndo.text}”</p>
          <p className="muted" style={{ margin: '10px 0 0' }}>That part of your site goes back to how it was. Nothing else changes.</p>
        </Confirm>
      )}
      {confirmRedesign && (
        <Confirm title="Start over with a fresh design?" yes="Yes, give me a new design" onNo={() => setConfirmRedesign(false)}
          onYes={() => { setConfirmRedesign(false); runNow({ redesign: true, instructions: [] }, 'Designing a fresh version of your site…'); }}>
          <p style={{ margin: 0 }}>Your whole site gets a new look: new layout, colors and fonts. Your business details, photos and earlier requests are kept.</p>
          <p className="muted" style={{ margin: '10px 0 0' }}>Takes about 3 to 5 minutes. You can’t switch back to this version afterward.</p>
        </Confirm>
      )}

      {target && (
        <div className="swap" role="dialog" aria-label="Replace image">
          <div className="swap__card">
            <button className="ask__x" onClick={() => setTarget(null)} aria-label="Close">×</button>
            <p className="eyebrow" style={{ marginBottom: 8 }}>Replace this image</p>
            <p className="muted" style={{ margin: '0 0 12px', wordBreak: 'break-all' }}>{target.src}</p>

            <label className="btn btn--gold ask__btn" style={{ marginBottom: 12 }}>
              {uploading === 'swap' ? 'Working…' : 'Upload a photo'}
              <input type="file" accept="image/*" hidden disabled={uploading === 'swap'}
                onChange={(e) => replaceByUpload(e.target.files)} />
            </label>

            <label>Or paste a link to an image you already have online</label>
            <input className="input" placeholder="https://…/photo.jpg" value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)} />
            <Button variant="ghost" style={{ marginTop: 10 }} disabled={uploading === 'swap' || !linkUrl.trim()}
              onClick={replaceByLink}>Use this image</Button>
            <p className="muted" style={{ marginTop: 10 }}>
              I'll download it and host it on your site, so it can't break later if the other page changes.
            </p>
            {uploadError && <p className="ask__err">{uploadError}</p>}
          </div>
        </div>
      )}

      <div className="price-bar" style={{ marginTop: 18, gap: 12, flexWrap: 'wrap' }}>
        <span className="muted" style={{ color: 'var(--paper-dim)' }}>
          {pending.length
            ? `${pending.length} change${pending.length > 1 ? 's' : ''} waiting. Your site updates when you press the button.`
            : project.live ? 'Add a change above, then update your site.' : 'Happy with it? Put it on your own web address.'}
        </span>
        <div className="row" style={{ justifyContent: 'flex-end', margin: 0 }}>
          {pending.length > 0 && <Button onClick={applyAll}>Update my site</Button>}
          {project.live
            ? <Button variant={pending.length ? 'ghost' : 'primary'} onClick={() => go('dashboard')}>Back to my sites</Button>
            : <Button variant={pending.length ? 'ghost' : 'primary'} onClick={() => go('domain')}>Make it live</Button>}
        </div>
      </div>
    </div>
  );
}
